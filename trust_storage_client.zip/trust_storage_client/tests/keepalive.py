import time


while True:
    time.sleep(0.1)